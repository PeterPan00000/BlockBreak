#include "Ball.h"



Ball::Ball()
{
}


Ball::~Ball()
{
}

void Ball::update() {
	for (auto& iter : balls) {
		iter.update();
	}
	auto& iter = std::remove_if(balls.begin(), balls.end(), [](const PokeBall& ins) {return ins.isDead(); });
	balls.erase(iter, balls.end());
}
void Ball::draw() {
	for (auto& iter : balls) {
		iter.draw();
	}
}
void Ball::add(Vec2 pos) {
	balls.emplace_back(pos);
}

void Ball::SetBarPos(Vec2 v1, Vec2 v2) {
	for (auto& iter : balls) {
		iter.SetBarPos(v1, v2);
	}
}