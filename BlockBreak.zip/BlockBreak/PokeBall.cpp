#include "PokeBall.h"


PokeBall::~PokeBall()
{
}

void PokeBall::update() {
	bar.setCenter(leftbarPos.x, leftbarPos.y);
	bar2.setCenter(rightbarPos.x, rightbarPos.y);

	rect.moveBy(ballSpeed);
	circle.moveBy(ballSpeed);

	if (circle.y < 0 && ballSpeed.y <  0)
	{
		ballSpeed.y *= -1;
	}
	//���ɂ���������
	if ((circle.x < 0 && ballSpeed.x < 0) || ((Window::Width() - 74) < circle.x && ballSpeed.x > 0))
	{
		ballSpeed.x *= -1;
	}

	//�ӂ��̋�
	if (ballSpeed.y > 0 && bar.intersects(circle))
	{
		Combo = 0;
		ballSpeed = Vec2((circle.x - bar.center.x) / 8, -ballSpeed.y).setLength(speed);
	}
	if (ballSpeed.y > 0 && bar2.intersects(circle))
	{
		Combo = 0;
		ballSpeed = Vec2((circle.x - bar2.center.x) / 8, -ballSpeed.y).setLength(speed);
	}
	if (rect.pos.y > Window::Height()) {
		Dead = true;
	}
}
void PokeBall::SetBarPos(Vec2 v1, Vec2 v2) {
	leftbarPos = v1;
	rightbarPos = v2;
}
void PokeBall::draw() {
	rect(texture).draw();
}
bool PokeBall::isDead() const{
	return Dead;
}

void PokeBall::ComboPlus() {
	Combo++;
}

int PokeBall::GetCombo() {
	return Combo;
}