#pragma once
#include<Siv3D.hpp>
class PokeBall
{
public:
	PokeBall(Vec2 _pos) :
		myPos(_pos) {
		rect.setCenter(myPos.x, myPos.y);
		circle.setPos(myPos.x, myPos.y);
	}
	~PokeBall();
	void update();
	void draw();
	bool isDead()const;
	void SetBarPos(Vec2, Vec2);
	void ComboPlus();
	int GetCombo();
	double speed = 8.0;
	Vec2 ballSpeed{ 0, -speed };
	RectF rect{ 48 };//texture�p
	Circle circle{ 24 };
	Vec2 myPos;
	Texture texture = Texture{ L"Example/�����X�^�[�{�[��.png" };
	bool Dead = false;
	int Combo = 0;
	Rect bar{ 180, 20 };
	Rect bar2{ 180, 20 };
	Vec2 leftbarPos;
	Vec2 rightbarPos;
	PokeBall& operator =(const PokeBall& pb) {
		this->speed = pb.speed;
		this->ballSpeed = pb.ballSpeed;
		this->rect = pb.rect;
		this->circle = pb.circle;
		this->myPos = pb.myPos;
		this->texture = pb.texture;
		this->Dead = pb.Dead;
		this->Combo = pb.Combo;
		this->bar = pb.bar;
		this->bar2 = bar2;
		this->leftbarPos = pb.leftbarPos;
		this->rightbarPos = pb.rightbarPos;

		return *this;
	}
};

