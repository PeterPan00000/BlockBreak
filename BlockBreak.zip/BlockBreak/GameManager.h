#pragma once
# include "ItemManager.h"
#include"Ball.h"
//kinect�g���Ȃ�true, �g��Ȃ��Ȃ�false
#define KINECTMODE false
struct Spark : IEffect
{
	Array<std::pair<Vec2, Vec2>> m_particles;

	Spark(const Point& pos, const Point& size) : m_particles(50)
	{
		for (auto& particle : m_particles)
		{
			particle.second = Circular(Random(40.0), Random(TwoPi));
			particle.first = pos.movedBy(Random(-size.x / 2, size.x / 2), Random(-size.y / 2, size.y / 2));
		}
	}

	bool update(double t) override
	{
		for (const auto& particle : m_particles)
		{
			const Vec2 pos = particle.first + particle.second * t + 0.5* t*t * Vec2(0, 120);
			Triangle(pos, 8.0, particle.second.x).draw(HSV(pos.y - 40).toColorF(1.0 - t));
		}

		return t < 1.0;
	}
};
struct TextEffect : IEffect
{
	const Font m_font;

	const int32 m_value;

	const Vec2 m_from;

	const double N = 1.0;

	const bool flg;

	TextEffect(const Font& font, const int32 value, const Vec2& from, bool f)
		: m_font(font)
		, m_value(value)
		, m_from(from)
		, flg(f) {}

	bool update(const double t) override
	{
		// N �b�ŏ�����

		if (t >= N)
		{
			return false;
		}

		const double alpha = N - t;
		if (flg) {
			m_font(L"+", m_value).drawCenter(m_from + Vec2(0, -40 * t), HSV(60 - m_value).toColorF(alpha));
		}
		else
		{
			m_font(L"-", m_value).drawCenter(m_from + Vec2(0, -40 * t), HSV(160 - m_value).toColorF(alpha));
		}
		return true;
	}
};

class GameManager
{
public:
	GameManager();
	~GameManager();
	void update();
	int GetHp();
	int MyScore();
	int BlockSize();
	int GetTime();
	void SetKinect();
	void GetKinectTexture();
	void StopSound();
	void soundMst();
	void AllReset();
	void SetMode(int);
	void StartOpenBGM();
	void StopOpenBGM();
	int endTime() {
		return stopwatch.s();
	}
private:
	int RandomItem();
	Effect effect;
	const Font font{ 40, Typeface::Heavy };
	ItemManager *im = new ItemManager();
	const Sound sound{ Wave(0.1s, [](double t) { return Fraction(t * 440)*0.5 - 0.25; }) };
	const Size blockSize{ 80, 40 };
	double speed = 5.0;
	Rect bar{ 180, 20 };
	Rect bar2{ 180, 20 };
	const double BallSize = 24;
	Circle ball{ 1920 * 0.75, 1080 * 0.75 - 50, BallSize };
	Circle MasterBall{ 1920 * 0.75, 1080 * 0.75 - 50, BallSize };//��ʊO
	Vec2 ballSpeed{ 0, -speed };
	Vec2 MasterballSpeed{ 0, -speed };
	Vec2 RightHand = Vec2(1920 / 2, 1080 / 2);
	Vec2 LeftHand = Vec2(1920 / 2, 1080 / 2);
	const double HandRadius = 50;
	int Score = 0;
	int Combo = 0;
	int ComboM = 0;
	bool MasterBallFlg = false;
	int myHp = 6;//�c�@
	int timespase = 0;
	bool GameFlg = false;
	DynamicTexture colorTexture;
	std::array<Optional<KinectV2Body>, 6> bodies;
	Array<Rect> blocks;
	
	Ball *balls = new Ball();
	const Texture textureM{ L"Example/MasterBall.png" };
	const Sound Pokesound{ L"Example/�쐶�|�P����.mp3" };
	const Sound Pokesound2{ L"Example/�|�P���������܂���.mp3" };
	const Sound Pokesound3{ L"Example/�O���W�I.mp3" };
	const Sound Pokesound4{ L"Example/�q�K�i.mp3" };
	const Sound Pokesound5{ L"Example/�V���i.mp3" };
	const Sound Pokesound6{ L"Example/open.mp3" };
	RectF mstRect{ 48 };
	int Mode = 0;
	int ElectrodeCnt = 5;
	Stopwatch stopwatch;
	bool swflg = true;
	int gameTime = 0;
	int penalty = 0;
	int TimeScore = 0;
};

