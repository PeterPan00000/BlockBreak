#include "DropItem.h"





DropItem::~DropItem()
{
}

void DropItem::update() {
	itemobj.moveBy(0, 5);
}
void DropItem::draw() {
	itemobj(texture).draw();
}

void DropItem::intersectBar(Vec2 posbar1, Vec2 posbar2) {
	if (itemobj.intersects(RectF(posbar1, Vec2(180, 20))) || itemobj.intersects(RectF(posbar2, Vec2(180, 20)))) {
		Dead = true;
	}
	//return (itemobj.intersects(RectF(posbar1, Vec2(180, 20))) | itemobj.intersects(RectF(posbar2, Vec2(180, 20))));
}
void DropItem::intersectBlock(Vec2 posblock) {
	//return itemobj.intersects(RectF(posblock, Vec2(80, 40)));
}

bool DropItem::isDead()const {
	return Dead;
}

bool DropItem::isDeadOut()const {
	return (Dead | Out);
}

Vec2 DropItem::GetPos() {
	return itemobj.center;
}

void DropItem::intersectWindow() {
	if (!itemobj.intersects(RectF(Vec2(0, 0), Vec2(Window::Width(), Window::Height())))) {
		Out = true;
	}
}

int DropItem::GetNum() {
	return Num;
}