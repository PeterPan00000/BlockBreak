#include "GameManager.h"




GameManager::GameManager()
{
	Window::Resize((int32)(1920 * 0.6), (int32)(1080 * 0.6));
	// ���[�v�Đ�����悤�ݒ�
	Pokesound.setLoop(true);

	if (!KinectV2::IsAvailable())
	{
		//return;
		Font(30).draw(L"kinect error : 1", Vec2(0.0, 0.0), Palette::Red);
		exit(1);
	}
	if (!KinectV2::Start())
	{
		//return;
		Font(30).draw(L"kinect error : 2", Vec2(0.0, 0.0), Palette::Red);
		exit(1);
	}
	
}

void GameManager::AllReset() {
	//auto& iter = std::remove_if(balls->balls.begin(), balls->balls.end(), [](const PokeBall& ins) {return true; });
	balls->balls.erase(balls->balls.begin(), balls->balls.end());
	blocks.erase(blocks.begin(), blocks.end());
	Pokesound.stop();
	Pokesound2.stop();
	Pokesound3.stop();
	Pokesound4.stop();
	Pokesound5.stop();
	Pokesound6.stop();
	MasterBall.setPos(-100,-100);
	ball.setPos(-100, -100);
	switch (Mode)
	{
	case 0:
		Pokesound.play();
		speed = 5.0;
		myHp = 6;//�c�@
		break;
	case 1:
		Pokesound4.play();
		speed = 10.0;
		myHp = 4;//�c�@
		break; 
	case 2:
		speed = 10.0;
		Pokesound5.play();
		myHp = 100;//�c�@
		break;
	default:
		break;
	}
	
	
	Score = 0;
	Combo = 0; 
	ComboM = 0;
	ElectrodeCnt = 5;
	MasterBallFlg = false;
	
	timespase = 0;
	GameFlg = false;
	swflg = true;
	for (auto p : step({ Window::Width() / blockSize.x , 5 }))
	{
		blocks.emplace_back((p*blockSize).moveBy(0, 60), blockSize);
	}
}
void GameManager::SetMode(int _mode) {
	Mode = _mode;
}
GameManager::~GameManager()
{
}
void GameManager::SetKinect() {
	if (!KinectV2::IsAvailable())
	{
		//return;
		Font(30).draw(L"kinect error : 1", Vec2(0.0, 0.0), Palette::Red);
		exit(1);
	}
	if (!KinectV2::Start())
	{
		//return;
		Font(30).draw(L"kinect error : 2", Vec2(0.0, 0.0), Palette::Red);
		exit(1);
	}
}
void GameManager::GetKinectTexture() {
	if (KinectV2::HasNewColorFrame())
	{
		KinectV2::GetColorFrame(colorTexture);
	}
	if (KinectV2::HasNewBodyFrame())
	{
		KinectV2::GetBodyFrame(bodies);
	}

}

void GameManager::update() {
	if (KinectV2::HasNewColorFrame())
	{
		KinectV2::GetColorFrame(colorTexture);
	}
	if (KinectV2::HasNewBodyFrame())
	{
		KinectV2::GetBodyFrame(bodies);
	}

	colorTexture.draw();
	int cnt = -1;
	double len = 1000000000;
	double lenMin = 100000000000000000;
	int BodyNum = -1;

	for (const auto& body : bodies) {
		if (!body)
		{
			continue;
		}

		//�ŏ�������jointNum��Get
		cnt++;
		len = Sqrt(body->joints[V2JointType::SpineShoulder].cameraSpacePos.x*body->joints[V2JointType::SpineShoulder].cameraSpacePos.x + body->joints[V2JointType::SpineShoulder].cameraSpacePos.y*body->joints[V2JointType::SpineShoulder].cameraSpacePos.y + body->joints[V2JointType::SpineShoulder].cameraSpacePos.z*body->joints[V2JointType::SpineShoulder].cameraSpacePos.z);
		if (len < lenMin) {
			lenMin = len;
			BodyNum = cnt;
		}
		
	}

	int Cnt2 = 0;
	for (const auto& body : bodies)
	{
		if (!body)
		{
			continue;
		}

		if (Cnt2 == BodyNum) {
			LeftHand = body->joints[V2JointType::HandLeft].colorSpacePos;
			RightHand = body->joints[V2JointType::HandRight].colorSpacePos;
		}
		for (const auto& joint : body->joints)
		{
			if (Cnt2 == BodyNum) {

				Circle(joint.colorSpacePos, 15).drawFrame(6.0, 0.0, Palette::Blue);//�Ȃ��ق��������H�������ق���������ۂ��H
			}
			else
			{

				Circle(joint.colorSpacePos, 15).drawFrame(6.0, 0.0, Palette::Red);//�Ȃ��ق��������H�������ق���������ۂ��H
			}
			Cnt2++;
		}

		
	}

	Circle(LeftHand, HandRadius).draw(Palette::Green);
	Circle(RightHand, HandRadius).draw(Palette::Green);

	if (Input::KeySpace.clicked) {
		GameFlg = true;
	}
	if (GameFlg) {
		ball.moveBy(ballSpeed);
		if (MasterBallFlg) {
			MasterBall.moveBy(MasterballSpeed);
		}
		if (KINECTMODE) {
			bar.setCenter((int)LeftHand.x,(int)LeftHand.y);
			bar2.setCenter((int)RightHand.x, (int)RightHand.y);
		}
		else
		{
			bar.setCenter(Mouse::Pos().x, (int)LeftHand.y);
			bar2.setCenter(Mouse::Pos().x + 100, (int)Mouse::Pos().y);
		}

		im->SetBarPos(bar.pos, bar2.pos);
		balls->SetBarPos(bar.center, bar2.center);

		for (auto it = blocks.begin(); it != blocks.end(); ++it)
		{

			if (it->intersects(ball))//block�j��
			{
				Combo++;//2�R���{�ȏ�łȂ񂩕\��
				if (Combo >= 2) {
					effect.add<TextEffect>(font, Combo, it->pos, true);
				}
				Score += Combo;
				if (Random(1, 20) % 4 == 0) {
					im->add(it->center, RandomItem());//�m����������K�v����
				}

				(it->bottom.intersects(ball) || it->top.intersects(ball)
					? ballSpeed.y : ballSpeed.x) *= -1;
				effect.add<Spark>(it->center, blockSize);
				blocks.erase(it);
				sound.playMulti();
				break;
			}

			if (MasterBallFlg) {
				if (it->intersects(MasterBall))//block�j��
				{
					ComboM++;//2�R���{�ȏ�łȂ񂩕\��
					if (ComboM >= 2) {
						effect.add<TextEffect>(font, ComboM, it->pos, true);
					}
					Score += ComboM;
					if (Random(1, 20) % 4 == 0) {
						im->add(it->center, RandomItem());//�m����������K�v����
					}

					effect.add<Spark>(it->center, blockSize);
					blocks.erase(it);
					sound.playMulti();
					break;
				}
			}
		}

		for (auto& iter : balls->balls) {
			for (auto it = blocks.begin(); it != blocks.end(); ++it)
			{

				if (it->intersects(iter.circle))//block�j��
				{
					iter.ComboPlus();//2�R���{�ȏ�łȂ񂩕\��
					if (iter.GetCombo() >= 2) {
						effect.add<TextEffect>(font, iter.GetCombo(), it->pos, true);
					}
					Score += iter.GetCombo();
					if (Random(1, 20) % 4 == 0) {
						im->add(it->center, RandomItem());//�m����������K�v����
					}

					(it->bottom.intersects(iter.circle) || it->top.intersects(iter.circle)
						? iter.ballSpeed.y : iter.ballSpeed.x) *= -1;
					effect.add<Spark>(it->center, blockSize);
					blocks.erase(it);
					sound.playMulti();
					break;
				}


			}
		}

		int winy = Window::Height();
		//reset
		if (Input::KeySpace.clicked||ball.y>(Window::Height()+200)) {
			myHp--;
			if (swflg) {
				stopwatch.start();
				stopwatch.restart();
				
				swflg = false;
			}
			if (myHp <= 0) {
			}
			else
			{
				ball.set(1920 * 0.75*0.5, 1080 * 0.75 - 50, BallSize);
				ballSpeed = Vec2(0, -speed);
				Combo = 0;
			}

		}
		//��蒼��
		if (Input::KeyShift.clicked) {
			
			if (myHp <= 0) {
			}
			else
			{
				ball.set(1920 * 0.75*0.5, 1080 * 0.75 - 50, BallSize);
				ballSpeed = Vec2(0, -speed);
				Combo = 0;
			}

		}

		for (auto const& block : blocks)
		{
			block.stretched(-1).draw(HSV(block.y - 40));
		}

		//��ɂ���������
		if (ball.y < 0 && ballSpeed.y < 0)
		{
			ballSpeed.y *= -1;
		}
		//���ɂ���������
		if ((ball.x < 0 && ballSpeed.x < 0) || ((Window::Width() - 82) < ball.x && ballSpeed.x > 0))
		{
			ballSpeed.x *= -1;
		}
		if (abs(ballSpeed.y) < 3) {
			ballSpeed.y *= 1.2;
		}
		
		//�ӂ��̋�
		if (ballSpeed.y > 0 && bar.intersects(ball))
		{
			Combo = 0;
			ballSpeed = Vec2((ball.x - bar.center.x) / 8, -ballSpeed.y).setLength(speed);
		}
		if (ballSpeed.y > 0 && bar2.intersects(ball))
		{
			Combo = 0;
			ballSpeed = Vec2((ball.x - bar2.center.x) / 8, -ballSpeed.y).setLength(speed);
		}

		if (MasterBallFlg) {
			//��ɂ���������
			if (MasterBall.y < 0 && MasterballSpeed.y < 0)
			{
				MasterballSpeed.y *= -1;
			}
			//���ɂ���������
			if ((MasterBall.x < 0 && MasterballSpeed.x < 0) || ((Window::Width() - 82) < MasterBall.x && MasterballSpeed.x > 0))
			{
				MasterballSpeed.x *= -1;
			}
			if (abs(MasterballSpeed.y) < 3) {
				MasterballSpeed.y *= 1.2;
			}
		}
		if (MasterBallFlg) {
			//�}�X�{
			if (MasterballSpeed.y > 0 && bar.intersects(MasterBall))
			{
				ComboM = 0;
				MasterballSpeed = Vec2((MasterBall.x - bar.center.x) / 8, -MasterballSpeed.y).setLength(speed);
			}
			if (MasterballSpeed.y > 0 && bar2.intersects(MasterBall))
			{
				ComboM = 0;
				MasterballSpeed = Vec2((MasterBall.x - bar2.center.x) / 8, -MasterballSpeed.y).setLength(speed);
			}
		}

		im->update();
		switch (im->Bonus().ItemNum)
		{
		case 0://�I�{��
			effect.add<TextEffect>(font, 1, im->Bonus().pos, true);
			Score++;
			break;
		case 1://�����{
			balls->add(im->Bonus().pos);
			break;
		case 2://�}���}�C��
			effect.add<TextEffect>(font, ElectrodeCnt, im->Bonus().pos, false);
			Score -= ElectrodeCnt;
			if (Mode == 1) {
				ElectrodeCnt += 5;
			}
			break;
		case 3://��������̋��̋�
			effect.add<TextEffect>(font, 5, im->Bonus().pos, true);
			Score += 5;
			break;
		case 4://�}�X�{
			if (!MasterBallFlg) {
				MasterBall.setPos(im->Bonus().pos);//���W��������ݒ肷��ׂ�
				effect.add<TextEffect>(font, 30, im->Bonus().pos, true);
				Score += 30;
				soundMst();
			}
			else
			{
				effect.add<TextEffect>(font, 10, im->Bonus().pos, true);
				Score += 10;
			}
			MasterBallFlg = true;
			break;
		default:
			break;
		}
		balls->update();
		balls->draw();
		im->draw();
		ball.draw(Palette::Orange);
		MasterBall.draw();
		mstRect.setCenter(MasterBall.center);
		mstRect(textureM).draw();
		bar.draw();
		bar2.draw();
		switch (Mode)
		{
		case 0:
			font(L"Score:", Score).draw(Vec2(0.0, Window::Height() - 200), Palette::Red);//�ʒu�v����
			break;
		case 1:
			font(L"Score:", Score).draw(Vec2(0.0, Window::Height() - 200), Palette::Red);//�ʒu�v����
			break;
		case 2:
			font(L"Score:", Score,L"  Time",stopwatch.s()).draw(Vec2(0.0, Window::Height() - 200), Palette::Red);//�ʒu�v����
			break;
		default:
			break;
		}
		
		effect.update();
	}
}

int GameManager::RandomItem() {
	//0:11,1:11,2:7,3:8,4:6	+5n
	int r;
	if (Mode == 1|| Mode == 2) {
		r = Random(1, 72);

		if (r >= 1 && r <= 26) {
			return 0;
		}
		else if (r >= 27 && r <= 35)
		{
			return 1;
		}
		else if (r >= 36 && r <= 59)
		{
			return 2;
		}
		else if (r >= 60 && r <= 68)
		{
			return 3;
		}
		else
		{
			return 4;
		}
	}
	else
	{
		r = Random(1, 77);

		if (r >= 1 && r <= 26) {
			return 0;
		}
		else if (r >= 27 && r <= 42)
		{
			return 1;
		}
		else if (r >= 43 && r <= 54)
		{
			return 2;
		}
		else if (r >= 55 && r <= 68)
		{
			return 3;
		}
		else
		{
			return 4;
		}

	}
	
	
}
int GameManager::GetHp() {
	return myHp;
}
int GameManager::MyScore() {
	return Score;
}
int GameManager::BlockSize() {
	return (int)blocks.size();
}
int GameManager::GetTime() {
	if (BlockSize() == 0) {
		timespase++;
	}
	return timespase;
}
void GameManager::StopSound() {
	Pokesound.stop();
	Pokesound3.stop();
	Pokesound4.stop();
	Pokesound5.stop();
	Pokesound2.play();
}
void GameManager::soundMst() {
	Pokesound.stop();
	Pokesound4.stop();
	Pokesound5.stop();

	Pokesound3.play();
}
void GameManager::StartOpenBGM() {
	Pokesound6.play();
}
void GameManager::StopOpenBGM() {
	Pokesound6.stop();
}
