#pragma once
#include"DropItem.h"
struct ItemBonus
{
	int ItemNum;
	Vec2 pos;
};
class ItemManager
{
public:
	ItemManager();
	~ItemManager();
	void update();
	void draw();
	void add(const Vec2,int);
	void SetBarPos(Vec2, Vec2);
	ItemBonus Bonus();
private:
	Array<DropItem> items;
	Vec2 leftbarPos;
	Vec2 rightbarPos;
	Texture texture[5];//��ŏC��
	int ItemNum = -1;
	ItemBonus bonus;
};

