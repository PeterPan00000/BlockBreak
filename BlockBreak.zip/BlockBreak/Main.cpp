﻿# include "GameManager.h"
# include <HamFramework.hpp>

struct CommonData
{
	int counter = 0;
	Font font{ 50 };
	Font fontr{ 50 };
	int t = 0;
	int state = 0;
	Font fontg{ 24 };
	int myscore = 0;
	int EndTime = 0;
	int GameMode = -1;
	GameManager *gm = new GameManager();;
};

using MyApp = SceneManager<String, CommonData>;

class Title : public MyApp::Scene
{
public:
	GUI gui{GUIStyle::Default};
	void init() override
	{
		Window::Resize((int32)(1920 * 0.6), (int32)(1080 * 0.6));
		m_data->gm->StartOpenBGM();
		gui.setTitle(L"Mode Select");
		// ボタン
		gui.add(L"bt1", GUIButton::Create(L"OK"));
		gui.add(L"mode", GUIRadioButton::Create({ L"Normal", L"Hard", L"TimeAtack" }, none, true));
	}

	void update() override
	{
		if (m_data->state == 3)
		{

			++m_data->counter;
			changeScene(L"Cnt1");
			m_data->gm->StopOpenBGM();

		}
	}

	void draw() const override
	{
		Window::ClientRect().draw(Palette::Blue);
		m_data->font(L"GAME START").drawCenter(Window::Center());
		
		if (gui.button(L"bt1").pushed) {
			if (gui.radioButton(L"mode").checked(0)) {
				m_data->gm->SetMode(0);
				m_data->t++;
				m_data->state = 3;
				m_data->GameMode = 0;
				m_data->gm->AllReset();
				
			}
			if (gui.radioButton(L"mode").checked(1)) {
				m_data->gm->SetMode(1);
				m_data->t++;
				m_data->state = 3;
				m_data->GameMode = 1;
				m_data->gm->AllReset();
			}
			if (gui.radioButton(L"mode").checked(2)) {
				m_data->gm->SetMode(2);
				m_data->t++;
				m_data->state = 3;
				m_data->GameMode = 2;
				m_data->gm->AllReset();
			}
			
		}
	}
};

class Cnt3 : public MyApp::Scene
{
public:

	const Font font2{ 80, Typeface::Bold, FontStyle::Outline };

	void init() override
	{
		font2.changeOutlineStyle({ HSV(40, 0.8, 1.0), Alpha(0), 4.0 });
	}

	void update() override
	{
		if (m_data->state == 2)
		{
			++m_data->counter;
			changeScene(L"Cnt2");
		}
	}

	void draw() const override
	{
		while (System::Update() && m_data->state == 3)
		{
			const double s = 0.2 + Time::GetMillisec() % 3000 / 1000.0;

			Graphics2D::SetTransform(Mat3x2::Scale(s, Window::Center()));

			const double alpha = Saturate(2.0 - s * 0.8);

			font2(L"③").drawCenter(Window::Center(), AlphaF(alpha));

			if (s > 3)break;
		}

		m_data->state = 2;
	}
};
class Cnt2 : public MyApp::Scene
{
public:
	const Font font2{ 80, Typeface::Bold, FontStyle::Outline };

	void init() override
	{
		font2.changeOutlineStyle({ HSV(40, 0.8, 1.0), Alpha(0), 4.0 });
	}

	void update() override
	{
		if (m_data->state == 1)
		{
			++m_data->counter;
			changeScene(L"Cnt1");
		}
	}

	void draw() const override
	{
		while (System::Update() && m_data->state == 2)
		{
			const double s = 0.2 + Time::GetMillisec() % 3000 / 1000.0;

			Graphics2D::SetTransform(Mat3x2::Scale(s, Window::Center()));

			const double alpha = Saturate(2.0 - s * 0.8);

			font2(L"②").drawCenter(Window::Center(), AlphaF(alpha));

			if (s > 3)break;
		}

		m_data->state = 1;
	}
};
class Cnt1 : public MyApp::Scene
{
public:
	const Font font2{ 80, Typeface::Bold, FontStyle::Outline };

	void init() override
	{
		font2.changeOutlineStyle({ HSV(40, 0.8, 1.0), Alpha(0), 4.0 });
	}

	void update() override
	{
		if (m_data->state == 0)
		{
			++m_data->counter;
			changeScene(L"Game");
		}
	}

	void draw() const override
	{
		while (System::Update() && m_data->state == 1)
		{
			const double s = 0.2 + Time::GetMillisec() % 3000 / 1000.0;

			Graphics2D::SetTransform(Mat3x2::Scale(s, Window::Center()));

			const double alpha = Saturate(2.0 - s * 0.8);

			font2(L"①").drawCenter(Window::Center(), AlphaF(alpha));

			if (s > 3)break;
		}

		m_data->state = 0;
		Graphics2D::SetTransform(Mat3x2::Scale(1, Window::Center()));
	}
};

class Game : public MyApp::Scene
{
public:
	
	//Stopwatch stopwatch;
	void init() override
	{
		//m_data->gm = new GameManager();

		//if (!KinectV2::IsAvailable())
		//{
		//	//return;
		//	Font(30).draw(L"kinect error : 1", Vec2(0.0, 0.0), Palette::Red);
		//	exit(1);
		//}
		//if (!KinectV2::Start())
		//{
		//	//return;
		//	Font(30).draw(L"kinect error : 2", Vec2(0.0, 0.0), Palette::Red);
		//	exit(1);
		//}
		//stopwatch.start();
	}

	void update() override
	{
		if (m_data->gm->GetHp()==0||(m_data->gm->BlockSize()==0&& m_data->gm->GetTime()==150))
		{
			++m_data->counter;
			m_data->myscore = m_data->gm->MyScore();
			m_data->gm->StopSound();
			m_data->EndTime = m_data->gm->endTime();
			changeScene(L"Result");
		}
	}

	void draw() const override
	{
		m_data->gm->update();
	}
};

class Result : public MyApp::Scene
{
public:
	const Texture texture_hiker{ L"Example/hiker.png" };

	void init() override
	{
		
	}

	void update() override
	{
		if (Input::MouseL.clicked)
		{
			++m_data->counter;
			changeScene(L"Title");
		}
	}

	void draw() const override
	{
		Window::ClientRect().draw(Palette::Green);
		if (m_data->GameMode == 2) {
			m_data->font(L"RESULT:", m_data->EndTime,L" 秒").drawCenter(Window::Center());
		}
		else
		{
			m_data->font(L"RESULT:", m_data->myscore).drawCenter(Window::Center());
		}
		if (m_data->GameMode == 2) {
			if (m_data->EndTime<50) {
				m_data->fontr(L"\n\nポケモンマスター").drawCenter(Window::Center());
			}
			else if (m_data->EndTime<70)
			{
				m_data->fontr(L"\n\nエリートトレーナー").drawCenter(Window::Center());
			}
			else if (m_data->EndTime<150)
			{
				m_data->fontr(L"\n\nかいパンやろう").drawCenter(Window::Center());
			}
			else
			{
				//texture_hiker.draw();
				m_data->fontr(L"\n\nやまおとこ(♂)").drawCenter(Window::Center(), Palette::Black);
			}
		}
		else
		{
			if (m_data->myscore>500) {
				m_data->fontr(L"\n\nポケモンマスター").drawCenter(Window::Center());
			}
			else if (m_data->myscore>300)
			{
				m_data->fontr(L"\n\nエリートトレーナー").drawCenter(Window::Center());
			}
			else if (m_data->myscore>150)
			{
				m_data->fontr(L"\n\nかいパンやろう").drawCenter(Window::Center());
			}
			else
			{
				//texture_hiker.draw();
				m_data->fontr(L"\n\nやまおとこ(♂)").drawCenter(Window::Center(), Palette::Black);
			}
		}
		
		
	}
};

void Main()
{
	MyApp manager;
	Window::Resize((int32)(1920 * 0.6), (int32)(1080 * 0.6));
	manager.add<Title>(L"Title");
	manager.add<Cnt1>(L"Cnt1");
	manager.add<Cnt2>(L"Cnt2");
	manager.add<Cnt3>(L"Cnt3");
	manager.add<Game>(L"Game");
	manager.add<Result>(L"Result");

	while (System::Update())
	{
		manager.updateAndDraw();
	}
}