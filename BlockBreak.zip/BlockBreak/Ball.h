#pragma once
#include"PokeBall.h"
class Ball
{
public:
	Ball();
	~Ball();
	void update();
	void draw();
	void add(Vec2);
	void SetBarPos(Vec2, Vec2);
	Array<PokeBall> balls;
	
};

