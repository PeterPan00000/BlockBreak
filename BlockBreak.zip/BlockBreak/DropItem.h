#pragma once
#include<Siv3D.hpp>

class DropItem
{
public:
	DropItem(Texture _texture, Vec2 _myPos,int _num) :
		texture(_texture)
		,myPos(_myPos)
		,Num(_num){	}
	~DropItem();
	void update();
	void draw();
	void intersectBar(Vec2,Vec2);
	void intersectBlock(Vec2);
	void intersectWindow();
	bool isDead()const;
	bool isDeadOut()const;
	int GetNum();
	Vec2 GetPos();
	DropItem& operator =(const DropItem& di) {
		this->myPos = di.myPos;
		this->texture = di.texture;
		this->itemobj = di.itemobj;
		this->Dead = di.Dead;
		this->Num = di.Num;
		this->Out = di.Out;
		return *this;
	}
private:
	Vec2 myPos;
	Texture texture;
	RectF itemobj{ myPos,48 };
	bool Dead = false;
	int Num;
	bool Out = false;

};

